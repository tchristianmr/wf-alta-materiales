sap.ui.define([], function () {
  "use strict";

  /**
   * Formatters de Dynamic Page — GAP_P2P_08.
   */
  var __exports = {
    semaforoIcon(bActivo) {
      return bActivo ? "sap-icon://accept" : "sap-icon://message-error";
    },
    /** Conteo para el badge de la pestaña "Vistas creadas" (MARC-PSTAT simulado). */
    contarCreadas(aVistas) {
      return aVistas ? aVistas.filter(v => v.creada).length : 0;
    },
    /** Conteo para el badge de la pestaña "Vistas en WF" (SWWWIHEAD simulado). */
    contarEnWF(aVistas) {
      return aVistas ? aVistas.filter(v => v.enWF).length : 0;
    }
  };
  return __exports;
});
//# sourceMappingURL=formatter-dbg.js.map
