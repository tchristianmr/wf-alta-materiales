sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace com.alen.mm.wfaltamat.controller
   */
  const App = Controller.extend("com.alen.mm.wfaltamat.controller.App", {
    onInit: function _onInit() {}
  });
  return App;
});
//# sourceMappingURL=App-dbg.controller.js.map
