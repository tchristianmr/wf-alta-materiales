sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace com.alen.mm.wfaltamat.controller
   */
  const Launchpad = Controller.extend("com.alen.mm.wfaltamat.controller.Launchpad", {
    onInit: function _onInit() {
      // sin estado propio: solo navega a los sub-launchpads de cada prototipo
    },
    getRouter: function _getRouter() {
      return this.getOwnerComponent().getRouter();
    },
    onAbrirPrototipo1: function _onAbrirPrototipo(_oEvent) {
      this.getRouter().navTo("wizardLaunchpad");
    },
    onAbrirPrototipo2: function _onAbrirPrototipo2(_oEvent) {
      this.getRouter().navTo("fclLaunchpad");
    },
    /** A diferencia de Prototipo 1/2, el 3 no tiene sub-launchpad propio: el SegmentedButton
     * de Creación/Extensión ya vive dentro de la Dynamic Page (propuesta-3-dynamic-page.md). */
    onAbrirPrototipo3: function _onAbrirPrototipo3(_oEvent) {
      this.getRouter().navTo("dynamicPage");
    }
  });
  return Launchpad;
});
//# sourceMappingURL=Launchpad-dbg.controller.js.map
