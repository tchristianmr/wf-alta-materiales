sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageToast", "sap/m/MessageBox", "../../model/formatter", "../../model/VistasManager", "../../model/models"], function (Controller, MessageToast, MessageBox, __formatter, __VistasManager, ____model_models) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const formatter = _interopRequireDefault(__formatter);
  const VistasManager = _interopRequireDefault(__VistasManager);
  const createSolicitudModel = ____model_models["createSolicitudModel"];
  const createMaterialHeaderDraft = ____model_models["createMaterialHeaderDraft"];
  /**
   * @namespace com.alen.mm.wfaltamat.wizard.controller
   */
  const Wizard = Controller.extend("com.alen.mm.wfaltamat.wizard.controller.Wizard", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this.formatter = formatter;
    },
    onInit: function _onInit() {
      // Modelo por defecto inmediato: la vista nunca debe quedar sin modelo. Si esto se omite,
      // los bindings simples (ej. "visible") caen al defaultValue del control (true) en vez de
      // a nuestro valor, y las expression bindings evalúan sobre "undefined" — bloqueando campos
      // silenciosamente. onRouteMatched reemplaza este modelo por el de modo correcto poco después.
      this.getView().setModel(createSolicitudModel("creacion"));
      const oRouter = this.getRouter();
      oRouter.getRoute("wizard")?.attachPatternMatched(this.onRouteMatched, this);
    },
    getRouter: function _getRouter() {
      return this.getOwnerComponent().getRouter();
    },
    getModel: function _getModel() {
      return this.getView().getModel();
    },
    getConfigRows: function _getConfigRows(sModelName) {
      return this.getView().getModel(sModelName).getProperty("/rows") || [];
    },
    getVistasManager: function _getVistasManager() {
      return new VistasManager(this.getConfigRows("responsableVista"), this.getConfigRows("statusVistas"), this.getConfigRows("combinacionVenta"), this.getConfigRows("tipoMaterialRango"), this.getConfigRows("ventaMaterial"));
    },
    /** Se dispara al entrar por el sub-launchpad: el modo (Crear/Extender) ya viene fijado por el tile. */onRouteMatched: function _onRouteMatched(oEvent) {
      const oArgs = oEvent.getParameter("arguments");
      const sModo = oArgs.modo === "extension" ? "extension" : "creacion";
      this.getView().setModel(createSolicitudModel(sModo));
      this.getWizard().discardProgress(this.getStep(0), false);
      this.getWizard().goToStep(this.getStep(0), true);
    },
    getWizard: function _getWizard() {
      return this.byId("wizWizardAlta");
    },
    getStep: function _getStep(iIndex) {
      return this.getWizard().getSteps()[iIndex];
    },
    showStrip: function _showStrip(sText, sType) {
      const oModel = this.getModel();
      oModel.setProperty("/ui/messageStripText", sText);
      oModel.setProperty("/ui/messageStripType", sType);
      oModel.setProperty("/ui/messageStripVisible", true);
    },
    clearStrip: function _clearStrip() {
      this.getModel().setProperty("/ui/messageStripVisible", false);
    },
    onVolver: function _onVolver() {
      this.getRouter().navTo("wizardLaunchpad");
    },
    // --- Paso 1: Datos Generales ---------------------------------------------------------------
    onLimpiar: function _onLimpiar() {
      const oModel = this.getModel();
      const sModo = oModel.getProperty("/header/modoSolicitud");
      oModel.setProperty("/header", createMaterialHeaderDraft(sModo));
      oModel.setProperty("/ui/step1Validated", false);
      oModel.setProperty("/ui/step2Validated", false);
      oModel.setProperty("/ui/rangoNumeracion", undefined);
      this.clearStrip();
    },
    onCentroChange: function _onCentroChange(_oEvent) {
      this.recalcStep1Validated();
    },
    onTipoMaterialChange: function _onTipoMaterialChange(_oEvent) {
      const oModel = this.getModel();
      const sTipoMaterial = oModel.getProperty("/header/tipoMaterial");
      const sRango = this.getVistasManager().calcularRangoNumeracion(sTipoMaterial);
      oModel.setProperty("/ui/rangoNumeracion", sRango);
      // Regla de validación UI #1: rango Interno ⇒ MATNR bloqueado y se limpia lo tecleado.
      if (sRango === "Interno" && oModel.getProperty("/header/modoSolicitud") !== "extension") {
        oModel.setProperty("/header/material", "");
      }
      this.recalcStep1Validated();
    },
    onTipoEntradaChange: function _onTipoEntradaChange(_oEvent) {
      const oModel = this.getModel();
      const sTipoEntrada = oModel.getProperty("/header/tipoEntrada");
      const oCatalogo = this.getConfigRows("tipoEntradaCatalogo");
      const oEncontrado = oCatalogo.find(c => c.idTipoEntrada === sTipoEntrada);
      oModel.setProperty("/header/tipoEntradaDesc", oEncontrado?.descripcion ?? "");
    },
    onModoProcesoChange: function _onModoProcesoChange(oEvent) {
      const iIndex = oEvent.getParameter("selectedIndex");
      this.getModel().setProperty("/header/modoProceso", iIndex === 0 ? "M" : "D");
    },
    /** Regla de validación UI #1 (segunda mitad): en Creación + rango Externo, valida que MATNR no exista ya en MARA. */onMaterialChange: function _onMaterialChange(_oEvent) {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      if (oHeader.modoSolicitud === "extension" && oHeader.material) {
        const oMaestro = this.getConfigRows("materialMaestro").find(m => m.material === oHeader.material);
        if (oMaestro) {
          oModel.setProperty("/header/tipoMaterial", oMaestro.tipoMaterial);
          oModel.setProperty("/header/ramo", oMaestro.ramo);
          oModel.setProperty("/header/descripcionEs", oMaestro.descripcionEs);
          oModel.setProperty("/header/descripcionEn", oMaestro.descripcionEs);
          oModel.setProperty("/header/umBase", oMaestro.umBase);
          oModel.setProperty("/header/sector", oMaestro.sector);
          oModel.setProperty("/header/grupoTipoPosGral", oMaestro.grupoTipoPosGral);
          oModel.setProperty("/header/grupoArticulos", oMaestro.grupoArticulos);
          oModel.setProperty("/header/jerarquiaProductos", oMaestro.jerarquiaProductos);
        } else {
          this.showStrip("El material capturado no existe.", "Error");
        }
      }
      this.recalcStep1Validated();
      this.recalcStep2Validated();
    },
    /** MD Paso 1 (Extensión): true si el material tecleado existe en el maestro (MARA simulado). */materialExisteEnMaestro: function _materialExisteEnMaestro(sMaterial) {
      return this.getConfigRows("materialMaestro").some(m => m.material === sMaterial);
    },
    recalcStep1Validated: function _recalcStep1Validated() {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const sRango = oModel.getProperty("/ui/rangoNumeracion");

      // MD Paso 1 (Extensión): el material es obligatorio y debe existir en el maestro (MARA simulado).
      if (oHeader.modoSolicitud === "extension") {
        if (!oHeader.material) {
          oModel.setProperty("/ui/step1Validated", false);
          return;
        }
        if (!this.materialExisteEnMaestro(oHeader.material)) {
          this.showStrip("El material capturado no existe.", "Error");
          oModel.setProperty("/ui/step1Validated", false);
          return;
        }
      }
      if (!oHeader.centro || !oHeader.tipoMaterial) {
        oModel.setProperty("/ui/step1Validated", false);
        return;
      }
      if (sRango === "Externo") {
        if (!oHeader.material) {
          oModel.setProperty("/ui/step1Validated", false);
          return;
        }
        if (oHeader.modoSolicitud === "creacion" && this.getVistasManager().existeMaterialEnSistema(oHeader.material)) {
          this.showStrip(`El material ${oHeader.material} ya existe — no puede reutilizarse para una Creación.`, "Error");
          oModel.setProperty("/ui/step1Validated", false);
          return;
        }
      }
      this.clearStrip();
      oModel.setProperty("/ui/step1Validated", true);
    },
    onSiguientePaso1: function _onSiguientePaso(_oEvent) {
      this.getWizard().nextStep();
    },
    // --- Paso 2: Datos Básicos ------------------------------------------------------------------
    onDenominacionChange: function _onDenominacionChange(_oEvent) {
      const oModel = this.getModel();
      oModel.setProperty("/header/descripcionEn", oModel.getProperty("/header/descripcionEs"));
      this.recalcStep2Validated();
    },
    onDatosBasicosChange: function _onDatosBasicosChange(_oEvent) {
      this.recalcStep2Validated();
    },
    recalcStep2Validated: function _recalcStep2Validated() {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const bJerarquiaOk = oHeader.tipoMaterial !== "FERT" || !!oHeader.jerarquiaProductos;
      oModel.setProperty("/ui/step2Validated", !!oHeader.descripcionEs && !!oHeader.umBase && bJerarquiaOk);
    },
    /** MD Paso 2 del User Journey — bloquea Secciones 1 y 2 (estadoProceso='Confirmado') y avanza. */onConfirmarDatos: function _onConfirmarDatos(_oEvent) {
      this.getModel().setProperty("/header/estadoProceso", "Confirmado");
      this.getWizard().nextStep();
    },
    // --- Paso 3: Selección de Vistas (Sección 4) -------------------------------------------------
    onStepVistasActivate: function _onStepVistasActivate(_oEvent) {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const oMgr = this.getVistasManager();
      const aVistas = oMgr.calcularVistasRequeridas(oHeader.centro, oHeader.tipoMaterial, oHeader.materialExportacion, oHeader.modoSolicitud === "extension" ? oHeader.material : undefined);
      oModel.setProperty("/vistasCrear", aVistas);
      // "Vistas de Ventas" — simula MVKE: vistas de venta ya existentes para el MATERIAL de la solicitud.
      oModel.setProperty("/vistasVenta", oMgr.calcularVistasVentaExistentes(oHeader.material));
      // "Canales de Dist. Conf." — Objeto Custom 2: combinaciones Org.Ventas/Canal configuradas para el TIPO DE MATERIAL.
      oModel.setProperty("/canalesConf", oMgr.calcularCombinacionesVenta(oHeader.tipoMaterial));
    },
    onVistaSelect: function _onVistaSelect(_oEvent) {
      // binding de dos vías (selected="{crear}") ya actualizó el modelo; nada más que hacer aquí.
    },
    /** MD Paso 3/4: valida y, si procede, baja la solicitud al Grid de la Sección 5. */onAgregar: function _onAgregar(_oEvent) {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const aVistas = oModel.getProperty("/vistasCrear");
      const sPaisCentro = this.getCentroPais(oHeader.centro);
      const oContexto = {
        tipoMaterial: oHeader.tipoMaterial,
        centro: oHeader.centro,
        paisCentro: sPaisCentro,
        orgVentas: oHeader.orgVentas,
        umBase: oHeader.umBase
      };
      const oResultado = this.getVistasManager().validarAgregar(oContexto, aVistas);
      if (!oResultado.valido) {
        this.showStrip(oResultado.mensaje ?? "No fue posible agregar la solicitud.", "Error");
        return;
      }
      const oHeaderCompleto = oModel.getProperty("/header");
      const oFila = this.getVistasManager().construirFilaGrid(oHeaderCompleto, aVistas);
      const aGrid = oModel.getProperty("/grid") || [];
      aGrid.push(oFila);
      oModel.setProperty("/grid", aGrid);
      this.syncHayRegistrosEnGrid();
      oModel.setProperty("/header/estadoProceso", "Agregado");
      this.clearStrip();
      MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("msgAgregado"));
      this.getWizard().nextStep();
    },
    getCentroPais: function _getCentroPais(sCentro) {
      const oValueHelpModel = this.getView().getModel("valueHelp");
      const aCentros = oValueHelpModel.getProperty("/centros") || [];
      return aCentros.find(c => c.key === sCentro)?.pais ?? "";
    },
    /** Mantiene /ui/hayRegistrosEnGrid sincronizado — usado por "Enviar Workflow" en vez de una
     * expression binding directa sobre ${/grid}.length, por consistencia con step1/2Validated. */
    syncHayRegistrosEnGrid: function _syncHayRegistrosEnGrid() {
      const oModel = this.getModel();
      const aGrid = oModel.getProperty("/grid") || [];
      oModel.setProperty("/ui/hayRegistrosEnGrid", aGrid.length > 0);
    },
    // --- Paso 4: Revisión y Confirmación (Sección 5) ---------------------------------------------
    onEliminarGridRow: function _onEliminarGridRow(oEvent) {
      const oModel = this.getModel();
      const oButton = oEvent.getSource();
      const oContext = oButton.getBindingContext();
      const sPath = oContext?.getPath();
      if (!sPath) {
        return;
      }
      const iIndex = Number(sPath.split("/").pop());
      const aGrid = oModel.getProperty("/grid").slice();
      aGrid.splice(iIndex, 1);
      oModel.setProperty("/grid", aGrid);
      this.syncHayRegistrosEnGrid();
    },
    /** MD Paso 5: reinicia el asistente para capturar otro material, conservando el Grid acumulado. */onOtroMaterial: function _onOtroMaterial(_oEvent) {
      const oModel = this.getModel();
      const sModo = oModel.getProperty("/header/modoSolicitud");
      oModel.setProperty("/header", createMaterialHeaderDraft(sModo));
      oModel.setProperty("/ui/step1Validated", false);
      oModel.setProperty("/ui/step2Validated", false);
      oModel.setProperty("/ui/rangoNumeracion", undefined);
      oModel.setProperty("/vistasCrear", []);
      oModel.setProperty("/vistasVenta", []);
      oModel.setProperty("/canalesConf", []);
      this.clearStrip();
      this.getWizard().discardProgress(this.getStep(0), false);
      this.getWizard().goToStep(this.getStep(0), true);
    },
    /** MD "Lógica del Detonador de Workflow": consolida el Grid y dispara la notificación (simulada). */onEnviarWorkflow: function _onEnviarWorkflow(_oEvent) {
      const oModel = this.getModel();
      const aGrid = oModel.getProperty("/grid") || [];
      const bAlgunMaquilado = aGrid.some(r => r.materialMaquilado);
      const fnEnviar = () => {
        MessageToast.show(`Workflow disparado correctamente para ${aGrid.length} registro(s). Se notificó a los responsables de cada vista vía SBWP / Fiori My Inbox.`, {
          duration: 5000
        });
        oModel.setProperty("/grid", []);
        this.syncHayRegistrosEnGrid();
        this.onOtroMaterial(_oEvent);
      };
      if (bAlgunMaquilado) {
        MessageBox.warning("Uno o más registros están marcados como Material Maquilado (ZMAQ1). Se notificará este detalle a los responsables antes de que abran la transacción de edición.", {
          onClose: fnEnviar
        });
      } else {
        fnEnviar();
      }
    }
  });
  return Wizard;
});
//# sourceMappingURL=Wizard-dbg.controller.js.map
