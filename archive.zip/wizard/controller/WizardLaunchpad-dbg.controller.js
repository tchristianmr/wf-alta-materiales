sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace com.alen.mm.wfaltamat.wizard.controller
   */
  const WizardLaunchpad = Controller.extend("com.alen.mm.wfaltamat.wizard.controller.WizardLaunchpad", {
    onInit: function _onInit() {
      // sin estado propio
    },
    getRouter: function _getRouter() {
      return this.getOwnerComponent().getRouter();
    },
    onVolver: function _onVolver() {
      this.getRouter().navTo("launchpad");
    },
    /** El tile fija el modo — confirmado con el arquitecto (el radio button del Paso 1 del MD queda fijo). */onCrearMaterial: function _onCrearMaterial(_oEvent) {
      this.getRouter().navTo("wizard", {
        modo: "creacion"
      });
    },
    onExtenderMaterial: function _onExtenderMaterial(_oEvent) {
      this.getRouter().navTo("wizard", {
        modo: "extension"
      });
    }
  });
  return WizardLaunchpad;
});
//# sourceMappingURL=WizardLaunchpad-dbg.controller.js.map
