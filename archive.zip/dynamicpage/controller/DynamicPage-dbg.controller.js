sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageToast", "sap/m/MessageBox", "../../model/formatter", "../../model/VistasManager", "../../model/models"], function (Controller, MessageToast, MessageBox, __formatter, __VistasManager, ____model_models) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const formatter = _interopRequireDefault(__formatter);
  const VistasManager = _interopRequireDefault(__VistasManager);
  const createDynamicPageModel = ____model_models["createDynamicPageModel"];
  const createMaterialHeaderDraft = ____model_models["createMaterialHeaderDraft"];
  /** Objeto Custom 3: códigos que habilitan el campo Folio (propuesta-3-dynamic-page.md, Regla A). */
  const CODIGOS_HABILITAN_FOLIO = ["DNP", "EE", "CA"];

  /**
   * @namespace com.alen.mm.wfaltamat.dynamicpage.controller
   */
  const DynamicPage = Controller.extend("com.alen.mm.wfaltamat.dynamicpage.controller.DynamicPage", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this.formatter = formatter;
    },
    onInit: function _onInit() {
      // Misma lección aprendida en Wizard/FCL: la vista nunca debe quedar sin modelo.
      this.getView().setModel(createDynamicPageModel());
    },
    getRouter: function _getRouter() {
      return this.getOwnerComponent().getRouter();
    },
    getModel: function _getModel() {
      return this.getView().getModel();
    },
    getConfigRows: function _getConfigRows(sModelName) {
      return this.getView().getModel(sModelName).getProperty("/rows") || [];
    },
    getVistasManager: function _getVistasManager() {
      return new VistasManager(this.getConfigRows("responsableVista"), this.getConfigRows("statusVistas"), this.getConfigRows("combinacionVenta"), this.getConfigRows("tipoMaterialRango"), this.getConfigRows("ventaMaterial"));
    },
    showStrip: function _showStrip(sText, sType) {
      const oModel = this.getModel();
      oModel.setProperty("/ui/messageStripText", sText);
      oModel.setProperty("/ui/messageStripType", sType);
      oModel.setProperty("/ui/messageStripVisible", true);
    },
    clearStrip: function _clearStrip() {
      this.getModel().setProperty("/ui/messageStripVisible", false);
    },
    materialExisteEnMaestro: function _materialExisteEnMaestro(sMaterial) {
      return this.getConfigRows("materialMaestro").some(m => m.material === sMaterial);
    },
    getCentroPais: function _getCentroPais(sCentro) {
      const oValueHelpModel = this.getView().getModel("valueHelp");
      const aCentros = oValueHelpModel.getProperty("/centros") || [];
      return aCentros.find(c => c.key === sCentro)?.pais ?? "";
    },
    // --- Captura activa: Datos Generales + Datos Básicos ------------------------------------------
    onModoSolicitudChange: function _onModoSolicitudChange(_oEvent) {
      // selectedKey del SegmentedButton ya actualizó /header/modoSolicitud (binding de dos vías).
      this.recalcFormValidated();
    },
    onCentroChange: function _onCentroChange(_oEvent) {
      this.recalcFormValidated();
    },
    onTipoMaterialChange: function _onTipoMaterialChange(_oEvent) {
      const oModel = this.getModel();
      const sTipoMaterial = oModel.getProperty("/header/tipoMaterial");
      const sRango = this.getVistasManager().calcularRangoNumeracion(sTipoMaterial);
      oModel.setProperty("/ui/rangoNumeracion", sRango);
      if (sRango === "Interno" && oModel.getProperty("/header/modoSolicitud") !== "extension") {
        oModel.setProperty("/header/material", "");
      }
      this.recalcFormValidated();
    },
    /** MD Propuesta 3, Regla de Negocio A: Folio visible solo si Tipo de Entrada es DNP/EE/CA. */onTipoEntradaChange: function _onTipoEntradaChange(_oEvent) {
      const oModel = this.getModel();
      const sTipoEntrada = oModel.getProperty("/header/tipoEntrada");
      const oCatalogo = this.getConfigRows("tipoEntradaCatalogo");
      const oEncontrado = oCatalogo.find(c => c.idTipoEntrada === sTipoEntrada);
      oModel.setProperty("/header/tipoEntradaDesc", oEncontrado?.descripcion ?? "");
      oModel.setProperty("/ui/isFolioVisible", CODIGOS_HABILITAN_FOLIO.includes(sTipoEntrada));
      if (!CODIGOS_HABILITAN_FOLIO.includes(sTipoEntrada)) {
        oModel.setProperty("/header/folio", "");
      }
    },
    onModoProcesoChange: function _onModoProcesoChange(oEvent) {
      const iIndex = oEvent.getParameter("selectedIndex");
      this.getModel().setProperty("/header/modoProceso", iIndex === 0 ? "M" : "D");
    },
    onMaterialChange: function _onMaterialChange(_oEvent) {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      if (oHeader.modoSolicitud === "extension" && oHeader.material) {
        const oMaestro = this.getConfigRows("materialMaestro").find(m => m.material === oHeader.material);
        if (oMaestro) {
          oModel.setProperty("/header/tipoMaterial", oMaestro.tipoMaterial);
          oModel.setProperty("/header/ramo", oMaestro.ramo);
          oModel.setProperty("/header/descripcionEs", oMaestro.descripcionEs);
          oModel.setProperty("/header/descripcionEn", oMaestro.descripcionEs);
          oModel.setProperty("/header/umBase", oMaestro.umBase);
          oModel.setProperty("/header/sector", oMaestro.sector);
          oModel.setProperty("/header/grupoTipoPosGral", oMaestro.grupoTipoPosGral);
          oModel.setProperty("/header/grupoArticulos", oMaestro.grupoArticulos);
          oModel.setProperty("/header/jerarquiaProductos", oMaestro.jerarquiaProductos);
        } else {
          this.showStrip("El material capturado no existe.", "Error");
        }
      }
      this.recalcFormValidated();
    },
    onDenominacionChange: function _onDenominacionChange(_oEvent) {
      const oModel = this.getModel();
      oModel.setProperty("/header/descripcionEn", oModel.getProperty("/header/descripcionEs"));
      this.recalcFormValidated();
    },
    onDatosBasicosChange: function _onDatosBasicosChange(_oEvent) {
      this.recalcFormValidated();
    },
    /** Consolida Datos Generales + Datos Básicos en un solo gate (sin pasos, igual que FCL). */recalcFormValidated: function _recalcFormValidated() {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const sRango = oModel.getProperty("/ui/rangoNumeracion");
      if (oHeader.modoSolicitud === "extension") {
        if (!oHeader.material) {
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
        if (!this.materialExisteEnMaestro(oHeader.material)) {
          this.showStrip("El material capturado no existe.", "Error");
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
      }
      if (!oHeader.centro || !oHeader.tipoMaterial) {
        oModel.setProperty("/ui/formValidated", false);
        return;
      }
      if (sRango === "Externo") {
        if (!oHeader.material) {
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
        if (oHeader.modoSolicitud === "creacion" && this.getVistasManager().existeMaterialEnSistema(oHeader.material)) {
          this.showStrip(`El material ${oHeader.material} ya existe — no puede reutilizarse para una Creación.`, "Error");
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
      }
      const bJerarquiaOk = oHeader.tipoMaterial !== "FERT" || !!oHeader.jerarquiaProductos;
      const bBasicosOk = !!oHeader.descripcionEs && !!oHeader.umBase && bJerarquiaOk;
      this.clearStrip();
      oModel.setProperty("/ui/formValidated", bBasicosOk);
    },
    /** Botón "Limpiar" — resetea solo la captura activa (no toca el grid de staging). */onLimpiar: function _onLimpiar(_oEvent) {
      const oModel = this.getModel();
      const sModo = oModel.getProperty("/header/modoSolicitud");
      oModel.setProperty("/header", createMaterialHeaderDraft(sModo));
      oModel.setProperty("/ui/formValidated", false);
      oModel.setProperty("/ui/rangoNumeracion", undefined);
      oModel.setProperty("/ui/isFolioVisible", true);
      this.clearStrip();
    },
    /** Bloquea Datos Generales/Básicos y calcula las vistas (Sección 4). */onConfirmarDatos: function _onConfirmarDatos(_oEvent) {
      const oModel = this.getModel();
      oModel.setProperty("/header/estadoProceso", "Confirmado");
      const oHeader = oModel.getProperty("/header");
      const oMgr = this.getVistasManager();
      const aVistas = oMgr.calcularVistasRequeridas(oHeader.centro, oHeader.tipoMaterial, oHeader.materialExportacion, oHeader.modoSolicitud === "extension" ? oHeader.material : undefined);
      oModel.setProperty("/vistasCrear", aVistas);
      // "Vistas de Ventas" — simula MVKE: vistas de venta ya existentes para el MATERIAL de la solicitud.
      oModel.setProperty("/vistasVenta", oMgr.calcularVistasVentaExistentes(oHeader.material));
      // "Canales de Dist. Conf." — Objeto Custom 2: combinaciones Org.Ventas/Canal configuradas para el TIPO DE MATERIAL.
      oModel.setProperty("/canalesConf", oMgr.calcularCombinacionesVenta(oHeader.tipoMaterial));
    },
    onModificarDatos: function _onModificarDatos(_oEvent) {
      const oModel = this.getModel();
      oModel.setProperty("/header/estadoProceso", "Captura");
      oModel.setProperty("/vistasCrear", []);
      oModel.setProperty("/vistasVenta", []);
      oModel.setProperty("/canalesConf", []);
      this.clearStrip();
    },
    onVistaSelect: function _onVistaSelect(_oEvent) {
      // binding de dos vías (selected="{crear}") ya actualizó el modelo; nada más que hacer aquí.
    },
    // --- Grid de Solicitudes (Staging) -------------------------------------------------------------
    /** Botón "Agregar al Listado" — valida, inserta en el grid y resetea la captura (Auto-Reset). */
    onAgregarAlListado: function _onAgregarAlListado(_oEvent) {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const aVistas = oModel.getProperty("/vistasCrear");
      const sPaisCentro = this.getCentroPais(oHeader.centro);
      const oContexto = {
        tipoMaterial: oHeader.tipoMaterial,
        centro: oHeader.centro,
        paisCentro: sPaisCentro,
        orgVentas: oHeader.orgVentas,
        umBase: oHeader.umBase
      };
      const oResultado = this.getVistasManager().validarAgregar(oContexto, aVistas);
      if (!oResultado.valido) {
        this.showStrip(oResultado.mensaje ?? "No fue posible agregar la solicitud.", "Error");
        return;
      }
      const oFila = this.getVistasManager().construirFilaGrid(oHeader, aVistas);
      const aGrid = oModel.getProperty("/grid") || [];
      aGrid.push(oFila);
      oModel.setProperty("/grid", aGrid);
      this.syncHayRegistrosEnGrid();
      this.clearStrip();
      MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("msgAgregado"));
      this.resetCapturaActiva();
    },
    /** Limpia la captura activa y la regresa a modo editable (Auto-Reset tras Agregar). */resetCapturaActiva: function _resetCapturaActiva() {
      const oModel = this.getModel();
      const sModo = oModel.getProperty("/header/modoSolicitud");
      oModel.setProperty("/header", createMaterialHeaderDraft(sModo));
      oModel.setProperty("/ui/formValidated", false);
      oModel.setProperty("/ui/rangoNumeracion", undefined);
      oModel.setProperty("/ui/isFolioVisible", true);
      oModel.setProperty("/vistasCrear", []);
      oModel.setProperty("/vistasVenta", []);
      oModel.setProperty("/canalesConf", []);
      this.clearStrip();
    },
    onEliminarGridRow: function _onEliminarGridRow(oEvent) {
      const oModel = this.getModel();
      const oButton = oEvent.getSource();
      const oContext = oButton.getBindingContext();
      const sPath = oContext?.getPath();
      if (!sPath) {
        return;
      }
      const iIndex = Number(sPath.split("/").pop());
      const aGrid = oModel.getProperty("/grid").slice();
      aGrid.splice(iIndex, 1);
      oModel.setProperty("/grid", aGrid);
      this.syncHayRegistrosEnGrid();
    },
    syncHayRegistrosEnGrid: function _syncHayRegistrosEnGrid() {
      const oModel = this.getModel();
      const aGrid = oModel.getProperty("/grid") || [];
      oModel.setProperty("/ui/hayRegistrosEnGrid", aGrid.length > 0);
    },
    // --- Footer global: Enviar a Workflow / Cancelar -----------------------------------------------
    onEnviarWorkflow: function _onEnviarWorkflow(_oEvent) {
      const oModel = this.getModel();
      const aGrid = oModel.getProperty("/grid") || [];
      const bAlgunMaquilado = aGrid.some(r => r.materialMaquilado);
      const fnEnviar = () => {
        MessageToast.show(`Workflow disparado correctamente para ${aGrid.length} registro(s). Se notificó a los responsables de cada vista vía SBWP / Fiori My Inbox.`, {
          duration: 5000
        });
        oModel.setProperty("/grid", []);
        this.syncHayRegistrosEnGrid();
        this.resetCapturaActiva();
      };
      if (bAlgunMaquilado) {
        MessageBox.warning("Uno o más registros están marcados como Material Maquilado (ZMAQ1). Se notificará este detalle a los responsables antes de que abran la transacción de edición.", {
          onClose: fnEnviar
        });
      } else {
        fnEnviar();
      }
    },
    /** Botón "Cancelar" — descarta la sesión completa (propuesta-3-dynamic-page.md, Regla B). */onCancelar: function _onCancelar(_oEvent) {
      const oBundle = this.getView().getModel("i18n").getResourceBundle();
      MessageBox.confirm(oBundle.getText("dpMsgCancelarTexto"), {
        title: oBundle.getText("dpMsgCancelarTitulo"),
        actions: [MessageBox.Action.YES, MessageBox.Action.NO],
        onClose: sAction => {
          if (sAction !== MessageBox.Action.YES) {
            return;
          }
          const oModel = this.getModel();
          oModel.setProperty("/grid", []);
          this.syncHayRegistrosEnGrid();
          this.resetCapturaActiva();
          this.getRouter().navTo("launchpad");
        }
      });
    }
  });
  return DynamicPage;
});
//# sourceMappingURL=DynamicPage-dbg.controller.js.map
