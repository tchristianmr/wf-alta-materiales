sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace com.alen.mm.wfaltamat.fcl.controller
   */
  const FCLLaunchpad = Controller.extend("com.alen.mm.wfaltamat.fcl.controller.FCLLaunchpad", {
    onInit: function _onInit() {
      // sin estado propio
    },
    getRouter: function _getRouter() {
      return this.getOwnerComponent().getRouter();
    },
    onVolver: function _onVolver() {
      this.getRouter().navTo("launchpad");
    },
    onGestionarMateriales: function _onGestionarMateriales(_oEvent) {
      this.getRouter().navTo("fcl");
    }
  });
  return FCLLaunchpad;
});
//# sourceMappingURL=FCLLaunchpad-dbg.controller.js.map
