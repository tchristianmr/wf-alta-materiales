sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageToast", "sap/m/MessageBox", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/f/library", "../../model/formatter", "../../model/VistasManager", "../../model/models"], function (Controller, MessageToast, MessageBox, Filter, FilterOperator, sap_f_library, __formatter, __VistasManager, ____model_models) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const LayoutType = sap_f_library["LayoutType"];
  const formatter = _interopRequireDefault(__formatter);
  const VistasManager = _interopRequireDefault(__VistasManager);
  const createCarritoModel = ____model_models["createCarritoModel"];
  const createMaterialHeaderDraft = ____model_models["createMaterialHeaderDraft"];
  /**
   * @namespace com.alen.mm.wfaltamat.fcl.controller
   */
  const FCL = Controller.extend("com.alen.mm.wfaltamat.fcl.controller.FCL", {
    constructor: function constructor() {
      Controller.prototype.constructor.apply(this, arguments);
      this.formatter = formatter;
    },
    onInit: function _onInit() {
      // Modelo por defecto inmediato — misma lección aprendida en el Wizard: la vista nunca debe
      // quedar sin modelo, o los bindings simples caen al defaultValue del control.
      this.getView().setModel(createCarritoModel());
    },
    getRouter: function _getRouter() {
      return this.getOwnerComponent().getRouter();
    },
    getModel: function _getModel() {
      return this.getView().getModel();
    },
    getConfigRows: function _getConfigRows(sModelName) {
      return this.getView().getModel(sModelName).getProperty("/rows") || [];
    },
    getVistasManager: function _getVistasManager() {
      return new VistasManager(this.getConfigRows("responsableVista"), this.getConfigRows("statusVistas"), this.getConfigRows("combinacionVenta"), this.getConfigRows("tipoMaterialRango"), this.getConfigRows("ventaMaterial"));
    },
    showStrip: function _showStrip(sText, sType) {
      const oModel = this.getModel();
      oModel.setProperty("/ui/messageStripText", sText);
      oModel.setProperty("/ui/messageStripType", sType);
      oModel.setProperty("/ui/messageStripVisible", true);
    },
    clearStrip: function _clearStrip() {
      this.getModel().setProperty("/ui/messageStripVisible", false);
    },
    onVolver: function _onVolver() {
      this.getRouter().navTo("fclLaunchpad");
    },
    getFclLayout: function _getFclLayout() {
      return this.byId("fclLayout");
    },
    /** Alterna el panel Detail entre ancho normal (dos columnas) y pantalla completa. */onExpandirColapsarDetalle: function _onExpandirColapsarDetalle(_oEvent) {
      const oModel = this.getModel();
      const bExpandido = !oModel.getProperty("/ui/fclLayoutExpandido");
      oModel.setProperty("/ui/fclLayoutExpandido", bExpandido);
      this.getFclLayout().setLayout(bExpandido ? LayoutType.MidColumnFullScreen : LayoutType.TwoColumnsMidExpanded);
    },
    /** Cierra el panel Detail y regresa a la vista de solo el Master (propuesta-2-split-app.md). */onCerrarDetalle: function _onCerrarDetalle(_oEvent) {
      this.getModel().setProperty("/ui/fclLayoutExpandido", false);
      this.getFclLayout().setLayout(LayoutType.OneColumn);
      this.resetCapturaActiva();
    },
    /** Trae de vuelta el panel Detail (dos columnas) tras haberlo cerrado con onCerrarDetalle. */mostrarPanelDetalle: function _mostrarPanelDetalle() {
      this.getModel().setProperty("/ui/fclLayoutExpandido", false);
      this.getFclLayout().setLayout(LayoutType.TwoColumnsMidExpanded);
    },
    materialExisteEnMaestro: function _materialExisteEnMaestro(sMaterial) {
      return this.getConfigRows("materialMaestro").some(m => m.material === sMaterial);
    },
    getCentroPais: function _getCentroPais(sCentro) {
      const oValueHelpModel = this.getView().getModel("valueHelp");
      const aCentros = oValueHelpModel.getProperty("/centros") || [];
      return aCentros.find(c => c.key === sCentro)?.pais ?? "";
    },
    // --- Captura activa: Datos Generales + Datos Básicos ------------------------------------------
    onModoSolicitudChange: function _onModoSolicitudChange(oEvent) {
      const iIndex = oEvent.getParameter("selectedIndex");
      this.getModel().setProperty("/header/modoSolicitud", iIndex === 1 ? "extension" : "creacion");
      this.recalcFormValidated();
    },
    onCentroChange: function _onCentroChange(_oEvent) {
      this.recalcFormValidated();
    },
    onTipoMaterialChange: function _onTipoMaterialChange(_oEvent) {
      const oModel = this.getModel();
      const sTipoMaterial = oModel.getProperty("/header/tipoMaterial");
      const sRango = this.getVistasManager().calcularRangoNumeracion(sTipoMaterial);
      oModel.setProperty("/ui/rangoNumeracion", sRango);
      if (sRango === "Interno" && oModel.getProperty("/header/modoSolicitud") !== "extension") {
        oModel.setProperty("/header/material", "");
      }
      this.recalcFormValidated();
    },
    onTipoEntradaChange: function _onTipoEntradaChange(_oEvent) {
      const oModel = this.getModel();
      const sTipoEntrada = oModel.getProperty("/header/tipoEntrada");
      const oCatalogo = this.getConfigRows("tipoEntradaCatalogo");
      const oEncontrado = oCatalogo.find(c => c.idTipoEntrada === sTipoEntrada);
      oModel.setProperty("/header/tipoEntradaDesc", oEncontrado?.descripcion ?? "");
    },
    onModoProcesoChange: function _onModoProcesoChange(oEvent) {
      const iIndex = oEvent.getParameter("selectedIndex");
      this.getModel().setProperty("/header/modoProceso", iIndex === 0 ? "M" : "D");
    },
    onMaterialChange: function _onMaterialChange(_oEvent) {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      if (oHeader.modoSolicitud === "extension" && oHeader.material) {
        const oMaestro = this.getConfigRows("materialMaestro").find(m => m.material === oHeader.material);
        if (oMaestro) {
          oModel.setProperty("/header/tipoMaterial", oMaestro.tipoMaterial);
          oModel.setProperty("/header/ramo", oMaestro.ramo);
          oModel.setProperty("/header/descripcionEs", oMaestro.descripcionEs);
          oModel.setProperty("/header/descripcionEn", oMaestro.descripcionEs);
          oModel.setProperty("/header/umBase", oMaestro.umBase);
          oModel.setProperty("/header/sector", oMaestro.sector);
          oModel.setProperty("/header/grupoTipoPosGral", oMaestro.grupoTipoPosGral);
          oModel.setProperty("/header/grupoArticulos", oMaestro.grupoArticulos);
          oModel.setProperty("/header/jerarquiaProductos", oMaestro.jerarquiaProductos);
        } else {
          this.showStrip("El material capturado no existe.", "Error");
        }
      }
      this.recalcFormValidated();
    },
    onDenominacionChange: function _onDenominacionChange(_oEvent) {
      const oModel = this.getModel();
      oModel.setProperty("/header/descripcionEn", oModel.getProperty("/header/descripcionEs"));
      this.recalcFormValidated();
    },
    onDatosBasicosChange: function _onDatosBasicosChange(_oEvent) {
      this.recalcFormValidated();
    },
    /** Consolida las validaciones de Datos Generales + Datos Básicos (Paso 1 + Paso 2 del Wizard) en un solo gate. */recalcFormValidated: function _recalcFormValidated() {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const sRango = oModel.getProperty("/ui/rangoNumeracion");

      // MD Paso 1 (Extensión): material obligatorio y debe existir en el maestro (MARA simulado).
      if (oHeader.modoSolicitud === "extension") {
        if (!oHeader.material) {
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
        if (!this.materialExisteEnMaestro(oHeader.material)) {
          this.showStrip("El material capturado no existe.", "Error");
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
      }
      if (!oHeader.centro || !oHeader.tipoMaterial) {
        oModel.setProperty("/ui/formValidated", false);
        return;
      }
      if (sRango === "Externo") {
        if (!oHeader.material) {
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
        if (oHeader.modoSolicitud === "creacion" && this.getVistasManager().existeMaterialEnSistema(oHeader.material)) {
          this.showStrip(`El material ${oHeader.material} ya existe — no puede reutilizarse para una Creación.`, "Error");
          oModel.setProperty("/ui/formValidated", false);
          return;
        }
      }
      const bJerarquiaOk = oHeader.tipoMaterial !== "FERT" || !!oHeader.jerarquiaProductos;
      const bBasicosOk = !!oHeader.descripcionEs && !!oHeader.umBase && bJerarquiaOk;
      this.clearStrip();
      oModel.setProperty("/ui/formValidated", bBasicosOk);
    },
    /** MD Paso 2 del User Journey — bloquea Datos Generales/Básicos y calcula las vistas (Sección 4). */onConfirmarDatos: function _onConfirmarDatos(_oEvent) {
      const oModel = this.getModel();
      oModel.setProperty("/header/estadoProceso", "Confirmado");
      const oHeader = oModel.getProperty("/header");
      const oMgr = this.getVistasManager();
      const aVistas = oMgr.calcularVistasRequeridas(oHeader.centro, oHeader.tipoMaterial, oHeader.materialExportacion, oHeader.modoSolicitud === "extension" ? oHeader.material : undefined);
      oModel.setProperty("/vistasCrear", aVistas);
      // "Vistas de Ventas" — simula MVKE: vistas de venta ya existentes para el MATERIAL de la solicitud.
      oModel.setProperty("/vistasVenta", oMgr.calcularVistasVentaExistentes(oHeader.material));
      // "Canales de Dist. Conf." — Objeto Custom 2: combinaciones Org.Ventas/Canal configuradas para el TIPO DE MATERIAL.
      oModel.setProperty("/canalesConf", oMgr.calcularCombinacionesVenta(oHeader.tipoMaterial));
    },
    /** "Permite re-editar el material activo" (propuesta-2-split-app.md, Sección 2). */onModificarDatos: function _onModificarDatos(_oEvent) {
      const oModel = this.getModel();
      oModel.setProperty("/header/estadoProceso", "Captura");
      oModel.setProperty("/vistasCrear", []);
      oModel.setProperty("/vistasVenta", []);
      oModel.setProperty("/canalesConf", []);
      this.clearStrip();
    },
    onVistaSelect: function _onVistaSelect(_oEvent) {
      // binding de dos vías (selected="{crear}") ya actualizó el modelo; nada más que hacer aquí.
    },
    // --- Carrito (Panel Izquierdo / Master) --------------------------------------------------------
    /** "Botón Agregar al Listado" — valida, inserta en el carrito con estado 'Listo' y resetea la captura. */
    onAgregarAlListado: function _onAgregarAlListado(_oEvent) {
      const oModel = this.getModel();
      const oHeader = oModel.getProperty("/header");
      const aVistas = oModel.getProperty("/vistasCrear");
      const sPaisCentro = this.getCentroPais(oHeader.centro);
      const oContexto = {
        tipoMaterial: oHeader.tipoMaterial,
        centro: oHeader.centro,
        paisCentro: sPaisCentro,
        orgVentas: oHeader.orgVentas,
        umBase: oHeader.umBase
      };
      const oResultado = this.getVistasManager().validarAgregar(oContexto, aVistas);
      if (!oResultado.valido) {
        this.showStrip(oResultado.mensaje ?? "No fue posible agregar la solicitud.", "Error");
        return;
      }
      const oFilaGrid = this.getVistasManager().construirFilaGrid(oHeader, aVistas);
      const oEstadoVisual = formatter.calcularEstadoVisualCarrito(oHeader.modoSolicitud, "Listo");
      const oItem = {
        id: oHeader.solicitudId,
        header: {
          ...oHeader,
          estadoProceso: "Agregado"
        },
        vistasSeleccionadas: aVistas.map(v => ({
          ...v
        })),
        vistasVenta: oModel.getProperty("/vistasVenta") || [],
        canalesConf: oModel.getProperty("/canalesConf") || [],
        filaGrid: oFilaGrid,
        estadoEnvio: "Listo",
        estadoIconSrc: oEstadoVisual.icon,
        estadoTexto: oEstadoVisual.text,
        estadoState: oEstadoVisual.state
      };
      const aCarrito = oModel.getProperty("/carrito") || [];
      aCarrito.push(oItem);
      oModel.setProperty("/carrito", aCarrito);
      this.syncHayRegistrosEnCarrito();
      this.clearStrip();
      MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("msgAgregado"));
      this.resetCapturaActiva();
    },
    /** Limpia el panel Detail y lo regresa a modo de captura activa (usado por Agregar y por "Nuevo"). */resetCapturaActiva: function _resetCapturaActiva() {
      const oModel = this.getModel();
      oModel.setProperty("/header", createMaterialHeaderDraft("creacion"));
      oModel.setProperty("/ui/formValidated", false);
      oModel.setProperty("/ui/rangoNumeracion", undefined);
      oModel.setProperty("/ui/modoLectura", false);
      oModel.setProperty("/ui/carritoSeleccionadoId", null);
      oModel.setProperty("/vistasCrear", []);
      oModel.setProperty("/vistasVenta", []);
      oModel.setProperty("/canalesConf", []);
      this.clearStrip();
    },
    /** Botón "Nuevo" en la cabecera del Master (propuesta-2-split-app.md, Sección 3, Regla 2). */onNuevoMaterial: function _onNuevoMaterial(_oEvent) {
      this.resetCapturaActiva();
      this.mostrarPanelDetalle();
    },
    /** Clic en un ítem del Master — carga el detalle exacto en modo Solo Lectura (Regla 1). */onSeleccionarCarritoItem: function _onSeleccionarCarritoItem(oEvent) {
      const oListItem = oEvent.getParameter("listItem");
      const oContext = oListItem?.getBindingContext();
      const oItem = oContext?.getObject();
      if (!oItem) {
        return;
      }
      const oModel = this.getModel();
      oModel.setProperty("/header", {
        ...oItem.header
      });
      oModel.setProperty("/vistasCrear", oItem.vistasSeleccionadas.map(v => ({
        ...v
      })));
      oModel.setProperty("/vistasVenta", oItem.vistasVenta);
      oModel.setProperty("/canalesConf", oItem.canalesConf);
      oModel.setProperty("/ui/modoLectura", true);
      oModel.setProperty("/ui/carritoSeleccionadoId", oItem.id);
      this.clearStrip();
      this.mostrarPanelDetalle();
    },
    onEliminarCarritoItem: function _onEliminarCarritoItem(oEvent) {
      const oContext = oEvent.getSource().getBindingContext();
      const oItem = oContext?.getObject();
      if (!oItem) {
        return;
      }
      const oModel = this.getModel();
      const aCarrito = (oModel.getProperty("/carrito") || []).filter(i => i.id !== oItem.id);
      oModel.setProperty("/carrito", aCarrito);
      this.syncHayRegistrosEnCarrito();
      if (oModel.getProperty("/ui/carritoSeleccionadoId") === oItem.id) {
        this.resetCapturaActiva();
      }
    },
    syncHayRegistrosEnCarrito: function _syncHayRegistrosEnCarrito() {
      const oModel = this.getModel();
      const aCarrito = oModel.getProperty("/carrito") || [];
      oModel.setProperty("/ui/hayRegistrosEnCarrito", aCarrito.length > 0);
    },
    onBuscarCarrito: function _onBuscarCarrito(oEvent) {
      const sQuery = oEvent.getParameter("newValue") || "";
      const oList = this.byId("fclListCarrito");
      const oBinding = oList.getBinding("items");
      if (!oBinding) {
        return;
      }
      if (!sQuery) {
        oBinding.filter([]);
        return;
      }
      const aFilters = [new Filter("filaGrid/material", FilterOperator.Contains, sQuery), new Filter("filaGrid/centro", FilterOperator.Contains, sQuery), new Filter("filaGrid/descripcion", FilterOperator.Contains, sQuery), new Filter("header/tipoMaterial", FilterOperator.Contains, sQuery)];
      oBinding.filter(new Filter({
        filters: aFilters,
        and: false
      }));
    },
    // --- Envío a Workflow ----------------------------------------------------------------------------
    /** MD "Lógica del Detonador de Workflow" — envío secuencial simulado con transición de estado por ítem. */
    onEnviarWorkflow: function _onEnviarWorkflow(_oEvent) {
      const oModel = this.getModel();
      const aCarrito = oModel.getProperty("/carrito") || [];
      const bAlgunMaquilado = aCarrito.some(i => i.header.materialMaquilado);
      const fnEnviar = () => {
        void this.enviarSecuencial(aCarrito);
      };
      if (bAlgunMaquilado) {
        MessageBox.warning("Uno o más registros están marcados como Material Maquilado (ZMAQ1). Se notificará este detalle a los responsables antes de que abran la transacción de edición.", {
          onClose: fnEnviar
        });
      } else {
        fnEnviar();
      }
    },
    enviarSecuencial: async function _enviarSecuencial(aCarrito) {
      const oModel = this.getModel();
      for (const oItem of aCarrito) {
        this.actualizarEstadoEnvioItem(oItem.id, "Enviando");
        // eslint-disable-next-line no-await-in-loop
        await new Promise(resolve => setTimeout(resolve, 400));
        this.actualizarEstadoEnvioItem(oItem.id, "Enviado");
      }
      await new Promise(resolve => setTimeout(resolve, 300));
      MessageToast.show(`Workflow disparado correctamente para ${aCarrito.length} registro(s). Se notificó a los responsables de cada vista vía SBWP / Fiori My Inbox.`, {
        duration: 5000
      });
      oModel.setProperty("/carrito", []);
      this.syncHayRegistrosEnCarrito();
      this.resetCapturaActiva();
    },
    actualizarEstadoEnvioItem: function _actualizarEstadoEnvioItem(sId, sEstado) {
      const oModel = this.getModel();
      const aCarrito = oModel.getProperty("/carrito") || [];
      const iIndex = aCarrito.findIndex(i => i.id === sId);
      if (iIndex === -1) {
        return;
      }
      const oEstadoVisual = formatter.calcularEstadoVisualCarrito(aCarrito[iIndex].header.modoSolicitud, sEstado);
      oModel.setProperty(`/carrito/${iIndex}/estadoEnvio`, sEstado);
      oModel.setProperty(`/carrito/${iIndex}/estadoIconSrc`, oEstadoVisual.icon);
      oModel.setProperty(`/carrito/${iIndex}/estadoTexto`, oEstadoVisual.text);
      oModel.setProperty(`/carrito/${iIndex}/estadoState`, oEstadoVisual.state);
    }
  });
  return FCL;
});
//# sourceMappingURL=FCL-dbg.controller.js.map
