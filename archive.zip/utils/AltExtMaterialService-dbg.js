sap.ui.define([], function () {
  "use strict";

  /**
   * ÚNICO punto de acceso a OData en WFALTAMAT — mismo principio que Utils.ts de handheldpp:
   * ningún controller ni vista llama al ODataModel directamente (bindContext, bindList, etc.).
   * Todo pasa por un método de esta clase.
   *
   * Contrato verificado contra el `$metadata` real de ZPP_UI_ALTEXTMATERIAL_O4.
   *
   * Reglas duras:
   * - `create`/`update`/`delete`/`read` de `ZPPD_R_ALTEXTMATERIAL` están vacíos en el backend —
   *   NUNCA usar CRUD estándar sobre esa entidad. Solo las 6 acciones bound.
   * - Los parámetros de las acciones viajan SUELTOS (`proceso` + `_material`, o `mtart` + `plant`).
   * - `proceso: "P"` es un flag de depuración interno de Janeth — nunca se expone aquí.
   * - `IM_ValMaterial` valida UNA vista (`views`, una sola letra) a la vez; en el envío `views` lleva todas concatenadas.
   * - `IM_SendWF` devuelve una fila por línea (`idlinea`, `material`, `id` S/W/E, `mensaje`); `proceso = "E"` solo lanza el WF.
   */
  class AltExtMaterialService {
    static DUMMY_KEY = "0";
    static NAMESPACE = "com.sap.gateway.srvd.zpp_ui_altextmaterial_srv.v0001";
    constructor(oModel) {
      this.oModel = oModel;
    }

    // --- Value Helps estáticas (✅ EntitySets reales, lectura simple) ------------------------------
    // Antes se bindeaban directo en el XML (`items="{altextmaterial>/...}"`) — se centralizan aquí
    // para que TODO el acceso a OData pase por esta clase, sin excepción.

    async getTiposMaterial() {
      return this.readEntitySet("/ZPPD_I_PRODUCTTYPE_VH");
    }
    async getRamos() {
      return this.readEntitySet("/ZPPD_I_INDUSTRYSECTOR_VH");
    }
    async getTiposEntrada() {
      return this.readEntitySet("/ZPPD_I_TIPENT_VH");
    }
    async getUnidadesMedida() {
      return this.readEntitySet("/ZPPD_I_UnitOfMeasureText_VH");
    }
    async getSectores() {
      return this.readEntitySet("/ZPPD_I_DivisionText_VH");
    }
    async getGruposTipoPosGral() {
      return this.readEntitySet("/ZPPD_I_ItemCategoryGroupTextVH");
    }
    async getGruposArticulos() {
      return this.readEntitySet("/ZPPD_I_PRODUCTGROUPTEXT_2_VH");
    }
    async getRangosNumeracion() {
      return this.readEntitySet("/ZPPD_I_MATERIALRANGO");
    }

    // --- Value Helps dependientes (✅ acciones bound funcionales) ----------------------------------

    async getPlantsByMtart(sMtart) {
      return this.callBoundActionCollection("IM_PlantByMtart", {
        mtart: sMtart,
        plant: ""
      });
    }
    async getOrgVtaByMtart(sMtart, sPlant) {
      return this.callBoundActionCollection("IM_OrgVtaByMtart", {
        mtart: sMtart,
        plant: sPlant
      });
    }

    // --- Validación -----------------------------------------------------------------------------

    async validarVista(oEntry) {
      return this.callBoundActionCollection("IM_ValMaterial", {
        proceso: "C",
        _material: [oEntry]
      });
    }

    // --- Creación / Extensión --------------------------------------------------------------------

    async crearMaterial(aMateriales) {
      return this.callBoundActionSingle("IM_CreateMaterial", {
        proceso: "C",
        _material: aMateriales
      });
    }
    async extenderMaterial(aMateriales) {
      return this.callBoundActionSingle("IM_ExtendMaterial", {
        proceso: "E",
        _material: aMateriales
      });
    }

    // --- Envío de Workflow ------------------------------------------------------------------------

    async enviarWorkflow(aMateriales, sProceso) {
      return this.callBoundActionCollection("IM_SendWF", {
        proceso: sProceso,
        _material: aMateriales
      });
    }

    // --- Mapeo dominio (UI) -> wire (RAP) ----------------------------------------------------------
    static mapHeaderToEntryParameters(oHeader, sViews, sRangoNumeracion) {
      return {
        idlinea: String(oHeader.solicitudId ?? "").slice(0, 36),
        material: oHeader.material,
        tipoMaterial: oHeader.tipoMaterial,
        ramo: oHeader.ramo,
        tipoEntrada: oHeader.tipoEntrada,
        centro: oHeader.centro,
        orgVtas: oHeader.orgVentas,
        flagMaquila: oHeader.materialMaquilado ? "X" : "",
        flagExpMat: oHeader.materialExportacion ? "X" : "",
        flagModPro: oHeader.modoProceso === "M" ? "F" : "D",
        descripcion: oHeader.descripcionEs,
        umBase: oHeader.umBase,
        sector: oHeader.sector,
        grupoTipoPosGral: oHeader.grupoTipoPosGral,
        grupoArticulos: oHeader.grupoArticulos,
        jerarquiaProductos: oHeader.jerarquiaProductos,
        matExt: sRangoNumeracion,
        views: sViews
      };
    }
    static mapViewsXCreateToVistasConfig(aViewsXCreate, aViewsWF) {
      return [...aViewsXCreate].sort((a, b) => a.idsec - b.idsec).map(v => {
        const oWf = aViewsWF.find(w => w.idView === v.vista);
        return {
          secuencia: v.idsec,
          vista: v.vista,
          descripcionVista: v.descripcion ?? "",
          usuarioResponsable: (v.wiUsuario ?? "").split("/").filter(u => !!u).join(", "),
          crear: false,
          creada: v.creada,
          enWF: v.enWF,
          wiTitulo: oWf?.descripcion,
          wiFechaCreacion: oWf?.fechacreacion,
          wiUsuario: oWf?.usuarios || undefined
        };
      });
    }

    // --- Motor genérico de lectura (entity sets simples) -------------------------------------------

    /** GET simple a un EntitySet, sin key ni acción — usado por las 7 Value Helps estáticas. */
    async readEntitySet(sEntitySetPath) {
      const oBinding = this.oModel.bindList(sEntitySetPath);
      const aContexts = (await oBinding.requestContexts()) ?? [];
      return aContexts.map(oContext => oContext.getObject());
    }

    // --- Motor genérico de invocación de acciones bound ---------------------------------------------
    bindAction(sActionName, mParameters) {
      const sEntityPath = `/ZPPD_R_ALTEXTMATERIAL(material='${AltExtMaterialService.DUMMY_KEY}')`;
      const oParentContext = this.oModel.bindContext(sEntityPath).getBoundContext();
      const oBinding = this.oModel.bindContext(`${AltExtMaterialService.NAMESPACE}.${sActionName}(...)`, oParentContext, {
        $$groupId: "$direct"
      });
      for (const [sName, vValue] of Object.entries(mParameters)) {
        oBinding.setParameter(sName, vValue);
      }
      return oBinding;
    }

    /** Para acciones cuyo `ReturnType` es un tipo simple (no `Collection(...)`). */
    async callBoundActionSingle(sActionName, mParameters) {
      const oBinding = this.bindAction(sActionName, mParameters);
      await oBinding.execute();
      return oBinding.getBoundContext().getObject();
    }

    /** Para acciones cuyo `ReturnType` es `Collection(...)`. */
    async callBoundActionCollection(sActionName, mParameters) {
      const oBinding = this.bindAction(sActionName, mParameters);
      await oBinding.execute();
      const vResult = oBinding.getBoundContext().getObject();
      return Array.isArray(vResult) ? vResult : vResult.value ?? [];
    }
  }
  return AltExtMaterialService;
});
//# sourceMappingURL=AltExtMaterialService-dbg.js.map
